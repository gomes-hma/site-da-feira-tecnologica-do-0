import { useState, useEffect, useRef } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import './App.css'

function App() {
  const containerRef = useRef(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  })

  // Transformações baseadas no progresso da rolagem
  const backgroundColor = useTransform(
    scrollYProgress,
    [0, 0.3, 0.5, 0.7, 1],
    ['#87CEEB', '#4A5568', '#1A202C', '#2D3748', '#E6F7FF']
  )

  const characterX = useTransform(scrollYProgress, [0, 1], ['0%', '80%'])
  const characterOpacity = useTransform(scrollYProgress, [0, 0.5, 0.7, 1], [1, 0.7, 0.9, 1])

  // Palavras negativas que aparecem durante a descida
  const negativeWords = [
    'Depressão', 'Ansiedade', 'Borderline', 'TDAH', 'Procrastinação',
    'Vícios', 'Autocrítica', 'Perfeccionismo', 'Isolamento', 'Fracasso',
    'Angústia', 'Desesperança', 'Culpa', 'Medo', 'Solidão',
    'Vergonha', 'Inadequação', 'Exaustão', 'Dúvida', 'Autossabotagem',
    'Negação', 'Impulsividade', 'Instabilidade'
  ]

  // Palavras positivas que aparecem durante a recuperação
  const positiveWords = [
    'Apoio', 'Amizade', 'Ajuda', 'Esperança', 'Recuperação',
    'Força', 'Resiliência', 'Cuidado', 'Compreensão', 'Amor',
    'Luz', 'Recomeço', 'Conexão', 'Bem-estar'
  ]

  return (
    <div ref={containerRef} className="relative">
      {/* Seção de rolagem principal */}
      <motion.div 
        className="fixed inset-0 w-full h-screen overflow-hidden"
        style={{ backgroundColor }}
      >
        {/* Personagem */}
        <motion.div
          className="absolute top-1/2 -translate-y-1/2 w-20 h-32 flex items-center justify-center"
          style={{ 
            left: characterX,
            opacity: characterOpacity
          }}
        >
          <div className="relative">
            {/* Corpo do personagem (silhueta simples) */}
            <svg viewBox="0 0 100 200" className="w-full h-full">
              {/* Cabeça */}
              <circle cx="50" cy="30" r="20" fill="currentColor" className="text-gray-800" />
              {/* Corpo */}
              <rect x="35" y="50" width="30" height="60" rx="15" fill="currentColor" className="text-gray-800" />
              {/* Braço esquerdo */}
              <rect x="20" y="60" width="15" height="50" rx="7" fill="currentColor" className="text-gray-800" />
              {/* Braço direito */}
              <rect x="65" y="60" width="15" height="50" rx="7" fill="currentColor" className="text-gray-800" />
              {/* Perna esquerda */}
              <rect x="35" y="110" width="12" height="70" rx="6" fill="currentColor" className="text-gray-800" />
              {/* Perna direita */}
              <rect x="53" y="110" width="12" height="70" rx="6" fill="currentColor" className="text-gray-800" />
            </svg>
          </div>
        </motion.div>

        {/* Palavras negativas (aparecem entre 30% e 70% do scroll) */}
        {negativeWords.map((word, index) => {
          const wordProgress = useTransform(
            scrollYProgress,
            [0.3, 0.5, 0.7],
            [0, 1, 0]
          )
          
          return (
            <motion.div
              key={`negative-${index}`}
              className="absolute text-red-600 font-bold pointer-events-none"
              style={{
                left: `${10 + (index * 15) % 80}%`,
                top: `${15 + (index * 25) % 70}%`,
                fontSize: `${1 + (index % 3) * 0.5}rem`,
                opacity: wordProgress
              }}
            >
              {word}
            </motion.div>
          )
        })}

        {/* Amigos (aparecem após 70% do scroll) */}
        <motion.div
          className="absolute top-1/2 left-[85%] -translate-y-1/2 flex gap-4"
          style={{
            opacity: useTransform(scrollYProgress, [0.7, 0.85], [0, 1])
          }}
        >
          {[1, 2, 3].map((friend) => (
            <div key={`friend-${friend}`} className="w-16 h-28">
              <svg viewBox="0 0 100 200" className="w-full h-full">
                <circle cx="50" cy="30" r="20" fill="currentColor" className="text-blue-600" />
                <rect x="35" y="50" width="30" height="60" rx="15" fill="currentColor" className="text-blue-600" />
                <rect x="20" y="60" width="15" height="50" rx="7" fill="currentColor" className="text-blue-600" />
                <rect x="65" y="60" width="15" height="50" rx="7" fill="currentColor" className="text-blue-600" />
                <rect x="35" y="110" width="12" height="70" rx="6" fill="currentColor" className="text-blue-600" />
                <rect x="53" y="110" width="12" height="70" rx="6" fill="currentColor" className="text-blue-600" />
              </svg>
            </div>
          ))}
        </motion.div>

        {/* Palavras positivas (aparecem após 70% do scroll) */}
        {positiveWords.map((word, index) => {
          const wordProgress = useTransform(
            scrollYProgress,
            [0.7, 0.85, 1],
            [0, 1, 1]
          )
          
          return (
            <motion.div
              key={`positive-${index}`}
              className="absolute text-green-600 font-bold pointer-events-none"
              style={{
                left: `${20 + (index * 18) % 70}%`,
                top: `${10 + (index * 30) % 80}%`,
                fontSize: `${1.2 + (index % 3) * 0.4}rem`,
                opacity: wordProgress
              }}
            >
              {word}
            </motion.div>
          )
        })}

        {/* Instrução de rolagem */}
        <motion.div
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-center"
          style={{
            opacity: useTransform(scrollYProgress, [0, 0.1], [1, 0])
          }}
        >
          <p className="text-lg font-semibold mb-2">Role para baixo para iniciar a jornada</p>
          <div className="animate-bounce">
            <svg className="w-8 h-8 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </div>
        </motion.div>

        {/* Mensagem final */}
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-center"
          style={{
            opacity: useTransform(scrollYProgress, [0.9, 1], [0, 1])
          }}
        >
          <h2 className="text-4xl font-bold mb-4 text-blue-800">Você não está sozinho</h2>
          <p className="text-xl text-gray-700">Com apoio, sempre há esperança de recomeço</p>
        </motion.div>
      </motion.div>

      {/* Espaçador para permitir a rolagem */}
      <div className="h-[500vh]" />

      {/* Seção de conteúdo informativo */}
      <section className="relative bg-white py-20 px-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold mb-8 text-center">Entendendo o Ciclo da Autodestruição Silenciosa</h2>
          
          <div className="prose prose-lg max-w-none">
            <h2 className="text-4xl font-bold mb-8 text-center">Pesquisa: Ciclo da Autodestruição Silenciosa e Transtornos Associados</h2>

            <h3 className="text-2xl font-semibold mt-8 mb-4">Introdução</h3>
            <p className="text-lg leading-relaxed mb-6">
              O conceito de autodestruição silenciosa ou autossabotagem refere-se a um padrão de comportamentos, pensamentos e sentimentos que, de forma consciente ou inconsciente, prejudicam o bem-estar, o sucesso e a felicidade de um indivíduo [1, 2]. Esses comportamentos podem ser sutis e se manifestar de diversas formas, muitas vezes disfarçados de proteção ou mecanismos de enfrentamento, mas que, a longo prazo, levam a um ciclo negativo de sofrimento e estagnação [3, 4].
            </p>

            <h3 className="text-2xl font-semibold mt-8 mb-4">Comportamentos Autodestrutivos Comuns</h3>
            <p className="text-lg leading-relaxed mb-4">
              Os comportamentos autodestrutivos não se limitam apenas a atos físicos explícitos, mas abrangem uma gama de ações e padrões mentais. Alguns exemplos incluem:
            </p>
            <div className="grid md:grid-cols-2 gap-4 mb-8">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Procrastinação</h4>
                <p className="text-sm">Adiar tarefas importantes, o que pode levar a sentimentos de culpa, ansiedade e fracasso [2].</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Vícios</h4>
                <p className="text-sm">Abuso de substâncias (álcool, drogas), jogos, comida, etc., como forma de lidar com emoções negativas ou escapar da realidade [2, 5].</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Falta de Autocuidado</h4>
                <p className="text-sm">Negligenciar a saúde física e mental, alimentação, sono e higiene pessoal [2].</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Busca Constante por Situações que Causam Dor</h4>
                <p className="text-sm">Manter-se em relacionamentos tóxicos, aceitar empregos insatisfatórios ou repetir padrões de fracasso [2].</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Isolamento Social</h4>
                <p className="text-sm">Afastar-se de amigos e familiares, o que pode agravar sentimentos de solidão e depressão [6].</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Autocrítica Excessiva</h4>
                <p className="text-sm">Um diálogo interno negativo e constante que mina a autoestima e a confiança [4].</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Perfeccionismo</h4>
                <p className="text-sm">A busca inatingível pela perfeição que leva à paralisia e ao medo de falhar.</p>
              </div>
            </div>

            <h3 className="text-2xl font-semibold mt-8 mb-4">Transtornos Psicológicos Associados</h3>
            <p className="text-lg leading-relaxed mb-4">
              O comportamento autodestrutivo está frequentemente associado a diversas condições de saúde mental. A identificação e o tratamento desses transtornos são cruciais para quebrar o ciclo [5, 6]. Entre os transtornos mais comumente relacionados, destacam-se:
            </p>
            <ul className="list-disc pl-6 space-y-2 mb-8">
              <li><strong>Depressão:</strong> Caracterizada por tristeza persistente, perda de interesse, baixa energia e sentimentos de desesperança. A autodestruição pode ser uma manifestação da desesperança e da falta de valor próprio [5, 6].</li>
              <li><strong>Ansiedade:</strong> Preocupação excessiva e persistente, medo e tensão. Comportamentos autodestrutivos podem surgir como tentativas disfuncionais de controlar ou aliviar a ansiedade [5].</li>
              <li><strong>Transtornos de Personalidade:</strong> Especialmente o Transtorno de Personalidade Borderline (TPB), que frequentemente envolve impulsividade, instabilidade emocional, automutilação e ideação suicida [6, 7].</li>
              <li><strong>Transtorno de Déficit de Atenção e Hiperatividade (TDAH):</strong> Embora menos óbvio, a dificuldade de organização e impulsividade podem levar a padrões de autossabotagem [6].</li>
              <li><strong>Transtornos Alimentares:</strong> Anorexia, bulimia e transtorno da compulsão alimentar, que são formas diretas de autodestruição física e emocional.</li>
              <li><strong>Transtorno do Estresse Pós-Traumático (TEPT):</strong> Indivíduos com TEPT podem se engajar em comportamentos autodestrutivos como forma de lidar com memórias traumáticas ou sentimentos de culpa.</li>
            </ul>

            <h3 className="text-2xl font-semibold mt-8 mb-4">O Ciclo da Autodestruição</h3>
            <p className="text-lg leading-relaxed mb-4">
              O ciclo da autodestruição é frequentemente descrito como uma espiral negativa que se alimenta de sentimentos como dor, fracasso, perda, angústia e decepção [4]. Ele pode ser perpetuado por esquemas disfuncionais de pensamento, como "não sou bom o bastante" ou "não mereço ser feliz", que levam a comportamentos que confirmam essas crenças, criando um ciclo vicioso [4].
            </p>

            <div className="bg-blue-50 border-l-4 border-blue-600 p-6 my-8">
              <h3 className="text-xl font-semibold mb-2">Busque Ajuda</h3>
              <p className="mb-2">
                Se você se identifica com esses padrões, saiba que não está sozinho. A recuperação é possível 
                com o apoio adequado.
              </p>
              <p className="text-sm">
                Procure um profissional de saúde mental, converse com amigos e familiares de confiança, 
                e lembre-se: pedir ajuda é um sinal de força, não de fraqueza.
              </p>
            </div>

            <h3 className="text-2xl font-semibold mt-8 mb-4">Quebrando o Ciclo</h3>
            <p className="text-lg leading-relaxed mb-4">
              Quebrar o ciclo da autodestruição requer consciência, apoio e, muitas vezes, ajuda profissional. 
              Algumas estratégias incluem:
            </p>
            <div className="space-y-3 mb-8">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <p><strong>Reconhecer os padrões:</strong> Identificar comportamentos autodestrutivos é o primeiro passo.</p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <p><strong>Buscar apoio profissional:</strong> Terapia e, quando necessário, medicação podem ser fundamentais.</p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <p><strong>Cultivar conexões:</strong> Manter relacionamentos saudáveis e buscar apoio social.</p>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <p><strong>Praticar o autocuidado:</strong> Priorizar a saúde física e mental através de hábitos saudáveis.</p>
              </div>
            </div>
          </div>
          <h3 className="text-2xl font-semibold mt-8 mb-4">Referências</h3>
          <ul className="list-disc pl-6 space-y-2 mb-8">
            <li>[1] Psicóloga Luana Nodari. (2021). *Comportamento autodestrutivo: como parar?* Disponível em: <a href="https://psicologaluananodari.com.br/como-parar-de-ter-comportamento-autodestrutivo/" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">https://psicologaluananodari.com.br/como-parar-de-ter-comportamento-autodestrutivo/</a></li>
            <li>[2] Psicólogos Berrini. (2025). *Autodestruição emocional: por que sabotamos nosso bem-estar?* Disponível em: <a href="https://www.psicologosberrini.com.br/blog/autodestruicao-emocional/" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">https://www.psicologosberrini.com.br/blog/autodestruicao-emocional/</a></li>
            <li>[3] UAI. (2018). *Autossabotagem é um ciclo repetitivo de sentimentos negativos e pode ser superada.* Disponível em: <a href="https://www.uai.com.br/app/noticia/saude/2018/03/06/noticias-saude,223122/autossabotagem-e-um-ciclo-repetitivo-de-sentimentos-negativos-e-pode-s.shtml" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">https://www.uai.com.br/app/noticia/saude/2018/03/06/noticias-saude,223122/autossabotagem-e-um-ciclo-repetitivo-de-sentimentos-negativos-e-pode-s.shtml</a></li>
            <li>[4] Miguel Lucas. (2016). *Como parar com o seu comportamento autodestrutivo.* Disponível em: <a href="https://www.miguellucas.com.br/como-parar-com-o-seu-comportamento-autodestrutivo/" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">https://www.miguellucas.com.br/como-parar-com-o-seu-comportamento-autodestrutivo/</a></li>
            <li>[5] Hipnose.com.br. (2024). *Comportamentos autodestrutivos: 5 formas de identificar e superar.* Disponível em: <a href="https://www.hipnose.com.br/blog/comportamentos-autodestrutivos/" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">https://www.hipnose.com.br/blog/comportamentos-autodestrutivos/</a></li>
            <li>[6] Wikipedia. *Comportamento autodestrutivo.* Disponível em: <a href="https://pt.wikipedia.org/wiki/Comportamento_autodestrutivo" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">https://pt.wikipedia.org/wiki/Comportamento_autodestrutivo</a></li>
            <li>[7] Acervo Mais. *Transtorno de Personalidade Borderline e sua relação com os comportamentos autodestrutivos e suicídio.* Disponível em: <a href="https://acervomais.com.br/index.php/saude/article/view/7052" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">https://acervomais.com.br/index.php/saude/article/view/7052</a></li>
          </ul>
        </div>
      </section>

      {/* Rodapé */}
      <footer className="bg-gray-900 text-white py-8 px-8 text-center">
        <p className="text-sm">
          Este site tem fins educativos e informativos. Não substitui o aconselhamento profissional.
        </p>
        <p className="text-xs mt-2 text-gray-400">
          Se você está em crise, procure ajuda imediatamente. CVV: 188 (24 horas)
        </p>
      </footer>
    </div>
  )
}

export default App

